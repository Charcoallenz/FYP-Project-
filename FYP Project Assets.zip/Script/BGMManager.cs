using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BGMManager : MonoBehaviour
{
    public AudioClip bgmClip;  // Reference to the background music clip
    private AudioSource audioSource;  // The AudioSource component

    void Start()
    {
        audioSource = GetComponent<AudioSource>();  // Get the AudioSource component

        if (bgmClip != null)
        {
            audioSource.clip = bgmClip;  // Set the clip to the AudioSource
            audioSource.loop = true;  // Set the audio to loop
            audioSource.Play();  // Start playing the music
        }
    }

    void Awake()
    {
        // This ensures the BGMManager persists between scenes
        DontDestroyOnLoad(gameObject);
    }
}
