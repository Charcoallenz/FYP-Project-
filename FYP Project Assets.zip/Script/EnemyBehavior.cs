using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyBehavior : MonoBehaviour
{   
    private Animator anim;  // Reference to the Animator component

    // Boolean flags to store whether certain parameters exist
    private bool hasVerticalSpeed;
    private bool hasIsAttacking;
    private bool hasDie;

    public Transform player;  // Reference to the player transform
    public GameObject arrowPrefab;  // Reference to the arrow prefab
    public Transform arrowSpawnPoint;  // Position where arrows will be fired from
    public float arrowSpeed = 5f;  // Speed of the arrow
    public float shootCooldown = 2f;  // Time between shots

    public Path pathToFollow;

    //PATH INFO
    public int currentWayPointID = 0;
    public float speed = 2;
    public float reachDistance = 0.4f;
    public float rotationSpeed = 5f;

    // Random shooting timing
    public float minShootTime = 4f;   // Minimum time between shots
    public float maxShootTime = 10f;  // Maximum time between shots
    private float nextShootTime; // Next time the enemy will shoot

    //DISTANCE TO NEXT WAYPOINT
    float distance;

    //OPTION TO CHOOSE BEZIER CURVE PATH
    public bool useBezier;

    //STATE OF ENEMY
    public enum EnemyStates
    {
        ON_PATH, // Following the path
        FLY_IN, // Fly into Formation
        IDLE, // Idle in Formation
        DIVE, // Random Dive towards the Bottom
        CHARGE // Charge towards Player
    }

    public EnemyStates enemyState;

    public int enemyID;
    public Formation formation;

    // Health
    public int health = 1;

    // Score
    public int inFormationScore;
    public int notInFormationScore;

    // Reference to the GameManager
    private GameManager gameManager;

    // Charge properties
    public bool chargeEnabled = false;  // Allow this enemy to charge
    public float chargeDelayMin = 5f;   // Minimum time before a charge
    public float chargeDelayMax = 15f;  // Maximum time before a charge
    private float chargeTimer;

    // Start is called before the first frame update
    void Start()
    {
        anim = GetComponent<Animator>();  // Get the Animator component

        // Check if the Animator has specific parameters
        if (anim != null)
        {
            hasVerticalSpeed = HasParameter(anim, "VerticalSpeed");
            hasIsAttacking = HasParameter(anim, "IsAttacking");
            hasDie = HasParameter(anim, "Die");
        }

        /// Make sure the arrow spawn point and prefab are assigned in the Inspector
        if (arrowSpawnPoint == null)
        {
            Debug.LogWarning("Arrow Spawn Point is missing. Please assign it in the Inspector.");
        }

        if (arrowPrefab == null)
        {
            Debug.LogWarning("Arrow Prefab is missing. Please assign it in the Inspector.");
        }
        
        // Set the first random shoot time
        SetNextShootTime();

        // Initialize the charge timer if charging is enabled
        if (chargeEnabled)
        {
            chargeTimer = Random.Range(chargeDelayMin, chargeDelayMax);
        }

        // Reference to GameManager
        gameManager = GameManager.instance;
        
        
    }

    // Update is called once per frame
    void Update()
    {
        // Handle animation parameters

        switch(enemyState)
        {
            case EnemyStates.ON_PATH:
                {
                    MoveOnPath(pathToFollow);
                }
                break;
            case EnemyStates.FLY_IN:
                {
                    MoveToFormation();
                }
                break;
            case EnemyStates.IDLE:
                {
                    /// Check if it's time to shoot
                    if (Time.time >= nextShootTime)
                    {
                        ShootArrow();
                        SetNextShootTime();  // Schedule the next shot after a random delay
                    }

                    if (chargeEnabled)
                    {
                        chargeTimer -= Time.deltaTime;
                        if (chargeTimer <= 0f)
                        {
                            enemyState = EnemyStates.CHARGE;
                        }
                    }

                }

                break;
            case EnemyStates.DIVE:
                {
                    MoveOnPath(pathToFollow);
                }
                break;
            case EnemyStates.CHARGE:
                ChargeTowardsBottom();
                break;
        }

    }

    // Utility function to check if the Animator has a specific parameter
    bool HasParameter(Animator animator, string paramName)
    {
        foreach (AnimatorControllerParameter param in animator.parameters)
        {
            if (param.name == paramName)
            {
                return true;
            }
        }
        return false;
    }

    // Set the next shoot time based on a random range
    void SetNextShootTime()
    {
        nextShootTime = Time.time + Random.Range(minShootTime, maxShootTime);
    }

    // Function to shoot an arrow
    void ShootArrow()
    {
        if (arrowSpawnPoint == null || arrowPrefab == null)
        {
            Debug.LogWarning("Arrow Spawn Point or Arrow Prefab is missing or destroyed.");
            return;  // Don't proceed if there's an issue with spawn point or prefab
        }

        // Trigger the shooting animation
        if (hasIsAttacking && anim != null)
        {
            anim.SetTrigger("Shoot");
        }

        // Instantiate the arrow prefab at the arrow spawn point
        GameObject arrow = Instantiate(arrowPrefab, arrowSpawnPoint.position, Quaternion.identity);

        // Set the arrow's velocity to move it downward
        Rigidbody2D rb = arrow.GetComponent<Rigidbody2D>();
        if (rb != null)
        {
            // Move the arrow downwards
            rb.velocity = Vector2.down * arrowSpeed;

            // Rotate the arrow to match its movement direction
            float angle = Mathf.Atan2(rb.velocity.y, rb.velocity.x) * Mathf.Rad2Deg;
            arrow.transform.rotation = Quaternion.Euler(0, 0, angle);
        }

        // Optionally destroy the arrow after a few seconds
        Destroy(arrow, 5f);
    }

    void ChargeTowardsBottom()
    {
        // Trigger the charging animation if available
        if (anim != null && HasParameter(anim, "IsCharging"))
        {
            anim.SetBool("IsCharging", true);
        }

        // Move the enemy downward
        transform.position += Vector3.down * speed * Time.deltaTime;

    }


    void MoveToFormation()
    {
        Vector3 targetPosition = formation.GetVector(enemyID);

        // Calculate the vertical speed
        float verticalSpeed = targetPosition.y - transform.position.y;

        // Calculate vertical speed and set Animator parameter
        if (hasVerticalSpeed)
        {
            anim.SetFloat("VerticalSpeed", Mathf.Abs(verticalSpeed));
        }

        transform.position = Vector3.MoveTowards(transform.position, targetPosition, speed * Time.deltaTime);
        
        //ROTATION
        // var direction = targetPosition - transform.position;
        //     if(direction != Vector3.zero)
        //     {
        //         float angle = Mathf.Atan2(direction.y, direction.x) * Mathf.Rad2Deg;
        //         transform.rotation = Quaternion.Euler(0, 0, angle);  // Rotate on Z-axis for 2D

        //     }

        // Force the enemy to face downward (rotate 180 degrees on the Z-axis for 2D)
        transform.rotation = Quaternion.Euler(0, 0, 0);  // This ensures the enemy is facing downward


        if(Vector3.Distance(transform.position, formation.GetVector(enemyID)) <= 0.0001f)
        {
            transform.position = targetPosition;
            transform.SetParent(formation.gameObject.transform);
            transform.eulerAngles = Vector3.zero;

            formation.enemyList.Add(new Formation.EnemyFormation(enemyID, transform.localPosition.x, transform.localPosition.y, this.gameObject));

            enemyState = EnemyStates.IDLE;
        }

    }

    void MoveOnPath(Path path)
    {
        Vector3 targetPosition;  // The position the enemy is moving toward

        if (useBezier)
        {
            //MOVING THE ENEMY
            distance = Vector3.Distance(path.bezierObjList[currentWayPointID], transform.position);
            transform.position = Vector3.MoveTowards(transform.position, path.bezierObjList[currentWayPointID], speed * Time.deltaTime);

            // Get target position for vertical speed calculation
            targetPosition = path.bezierObjList[currentWayPointID];

        }
        else
        {
            distance = Vector3.Distance(path.pathObjList[currentWayPointID].position, transform.position);
            transform.position = Vector3.MoveTowards(transform.position, path.pathObjList[currentWayPointID].position, speed * Time.deltaTime);

            // Get target position for vertical speed calculation
            targetPosition = path.pathObjList[currentWayPointID].position;

        }
        // Calculate the vertical speed based on the Y difference between the target and current position
        float verticalSpeed = targetPosition.y - transform.position.y;

        // If vertical speed is very close to zero, set it to zero
        if (Mathf.Abs(verticalSpeed) < 0.05f)
        {
            verticalSpeed = 0;
        }

        // Set the VerticalSpeed parameter only if the Animator has it
        if (hasVerticalSpeed)
        {
            anim.SetFloat("VerticalSpeed", Mathf.Abs(verticalSpeed));
        }

        if(useBezier)
        {
            if(distance<=reachDistance)
            {
                currentWayPointID++;
            }
            if(currentWayPointID>= path.bezierObjList.Count)
            {
                currentWayPointID = 0;

                // Diving
                if(enemyState == EnemyStates.DIVE)
                {
                    transform.position = GameObject.Find("SpawnManager").transform.position;
                    Destroy(pathToFollow.gameObject);
                }
                enemyState = EnemyStates.FLY_IN;
            }
        }
        else
        {
            if(distance<=reachDistance)
            {
                currentWayPointID++;
            }
            if(currentWayPointID>= path.pathObjList.Count)
            {
                currentWayPointID = 0;

                // Diving
                if(enemyState == EnemyStates.DIVE)
                {
                    transform.position = GameObject.Find("SpawnManager").transform.position;
                    Destroy(pathToFollow.gameObject);
                }
                
                enemyState = EnemyStates.FLY_IN;
            }
        }
    }

    public void SpawnSetup(Path path, int ID, Formation _formation)
    {
        pathToFollow = path;
        enemyID = ID;
        formation = _formation;
    }

    public void DiveSetup(Path path)
    {
        pathToFollow = path;
        transform.SetParent(transform.parent.parent);
        enemyState = EnemyStates.DIVE;
    } 

    public void TakeDamage(int amount)
    {
        health -= amount;
        if(health <=0)
        {
            // Play Sound

            // Death Animation
            anim.SetTrigger("Die");

            // Add Score
            if(enemyState == EnemyStates.IDLE)
            {
                GameManager.instance.AddScore(inFormationScore);
            }
            else
            {
                GameManager.instance.AddScore(notInFormationScore);
            }

            // Report to Formation
            for (int i = 0; i < formation.enemyList.Count; i++)
            {
                // Check if EnemyID is Represented
                if(formation.enemyList[i].index == enemyID)
                {
                    formation.enemyList.Remove(formation.enemyList[i]);
                }
            }

            // Report to Spawn Manager
            SpawnManager sp = GameObject.Find("SpawnManager").GetComponent<SpawnManager>();
            // for (int i = 0; i < sp.spawnedEnemies.Count; i++)
            // {
            //     sp.spawnedEnemies.Remove(this.gameObject);
            // }
            sp.UpdateSpawnedEnemies(this.gameObject);

            // Report to game manager
            GameManager.instance.ReduceEnemy();

            // Remove Enemy
            Destroy(gameObject, 1f);
        }
    }

    void OnTriggerEnter2D(Collider2D other)
    {
        if (other.CompareTag("BottomZone"))  // Assuming you tag the BottomZone as "BottomZone"
        {
            if (enemyState == EnemyStates.CHARGE || enemyState == EnemyStates.DIVE)
            {
                // Player loses 50 points
                GameManager.instance.AddScore(-50);

                // Report to GameManager to reduce the enemy count
                GameManager.instance.ReduceEnemy();

                // Destroy the enemy
                Destroy(gameObject);
            }
        }
    }

}
