using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class UIScript : MonoBehaviour
{
    public static UIScript instance;

    public TextMeshProUGUI scoreText;
    public TextMeshProUGUI lifeText;
    public TextMeshProUGUI stageText;

    void Awake()
    {
        instance = this;
    }

    public void UpdateScoreText(int amount)
    {
        scoreText.text = amount.ToString("D9");
    }

    public void UpdateLifeText(int amount)
    {
        lifeText.text = "x" + amount.ToString("D2");
    }

    public void ShowStageText(int amount)
    {
        stageText.gameObject.SetActive(true);
        stageText.text = "Stage " + amount;

        Invoke("DeativateStagetext", 3f);
    }

    void DeativateStagetext()
    {
        stageText.gameObject.SetActive(false);
        CancelInvoke("DeativateStagetext");

    }
}
