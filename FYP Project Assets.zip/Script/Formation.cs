using System.Collections;
using System.Collections.Generic;
using UnityEngine;

#if UNITY_EDITOR
using UnityEditor;
#endif

public class Formation : MonoBehaviour
{
    public bool allowMovement = true;  // New boolean to control movement

    public int gridSizeX = 10;
    public int gridSizeY = 2;

    public float gridOffsetX = 2f;
    public float gridOffsetY = 2f;

    public int div = 4;

    public List<Vector3> gridList = new List<Vector3>();

    //Move the Formation
    public float maxMoveOffsetX = 5f;
    public float speed = 1f;
    int direction = -1;

    float curPosX; //Moving Position
    Vector3 startPosition;

    // Spreading
    bool canSpread;
    bool spreadStarted;

    float spreadAmount = 1f;
    float curSpread;
    float spreadSpeed = 0.5f;
    int spreadDir = 1;

    // Flying Dive
    bool canDive;
    public List<GameObject> divePathList = new List<GameObject>();

    [HideInInspector] public List<EnemyFormation> enemyList = new List<EnemyFormation>();

    [System.Serializable]
    public class EnemyFormation
    {
        public int index;
        public float xPos;
        public float yPos;
        public GameObject enemy;

        public Vector3 goal;
        public Vector3 start;

        public EnemyFormation (int _index, float _xPos, float _yPos, GameObject _enemy)
        {
            index = _index;
            xPos = _xPos;
            yPos = _yPos;
            enemy = _enemy;

            start = new Vector3(_xPos, _yPos, 0);
            goal = new Vector3(_xPos + (_xPos * 0.3f), yPos, 0);
        }
    }



    void Start()
    {
        startPosition = transform.position;
        curPosX = transform.position.x;

        CreateGrid();
    }

    void Update()
    {

        // Only move the formation if movement is allowed
        if (allowMovement)
        {
            if(!canSpread && !spreadStarted)
            {
                // Left Right Movement
                curPosX += Time.deltaTime * speed * direction;
                if (curPosX >= maxMoveOffsetX)
                {
                    direction *= -1;
                    curPosX = maxMoveOffsetX;
                }
                else if (curPosX <= -maxMoveOffsetX)
                {
                    direction *= -1;
                    curPosX = -maxMoveOffsetX;
                }
                transform.position = new Vector3(curPosX, startPosition.y, 0);
            }
            if(canSpread)
            {
                // Spread depending on their position
                curSpread += Time.deltaTime * spreadDir * spreadSpeed;
                if(curSpread >= spreadAmount || curSpread <= 0)
                {
                    //Change Spread Direction
                    spreadDir *= -1;
                }

                // Loop through enemyList and check for null
                for (int i = 0; i < enemyList.Count; i++)
                {
                    if (enemyList[i].enemy == null) 
                    {
                        // Skip if the enemy has been destroyed
                        continue;
                    }

                    // Move only if the enemy still exists
                    if (Vector3.Distance(enemyList[i].enemy.transform.position, enemyList[i].goal) >= 0.001f)
                    {
                        enemyList[i].enemy.transform.position = Vector3.Lerp(transform.position + enemyList[i].start, transform.position + enemyList[i].goal, curSpread);
                    }
                }

                // for (int i = 0; i < enemyList.Count; i++)
                // {
                //     if(Vector3.Distance(enemyList[i].enemy.transform.position, enemyList[i].goal) >= 0.001f)
                //     {
                //         enemyList[i].enemy.transform.position = Vector3.Lerp(transform.position + enemyList[i].start, transform.position + enemyList[i].goal, curSpread);
                //     }
                // }

            }

        }

        // if(canDive)
        // {
        //     Invoke("SetDiving", Random.Range(3, 10));
        //     canDive = false;
        // }
    }

    // Routine to Take Care of Spread
    public IEnumerator ActivateSpread()
    {
        if(spreadStarted)
        {
            yield break;
        }
        spreadStarted = true;

        while(transform.position.x != startPosition.x)
        {
            transform.position = Vector3.MoveTowards(transform.position, startPosition, speed * Time.deltaTime);
            yield return null;
        }
        canSpread = true;
        //canDive = true;
        Invoke("SetDiving", Random.Range(3, 10));

    }

    // End of Move Code

    
    // Draw Formation Grid
    void OnDrawGizmos()
    {
        gridList.Clear();

        int num = 0;

        for (int i = 0; i < gridSizeX; i++)
        {
            for (int j = 0; j < gridSizeY; j++)
            {
                float x = (gridOffsetX + gridOffsetX * 2 * (num/div)) * Mathf.Pow(-1, num%2+1);
                float y = gridOffsetY * ((num%div)/2);

                Vector3 vec = new Vector3(this.transform.position.x + x, this.transform.position.y + y, 0);

                // Visualize the Grid
                #if UNITY_EDITOR
                Handles.Label(vec, num.ToString());
                num++;
                #endif

                gridList.Add(vec);
            }
        }
    }
    //*/

    //Drae Grid for Enemy to Follow without Gizmo
    void CreateGrid()
    {
        gridList.Clear();

        int num = 0;

        for (int i = 0; i < gridSizeX; i++)
        {
            for (int j = 0; j < gridSizeY; j++)
            {
                float x = (gridOffsetX + gridOffsetX * 2 * (num / div)) * Mathf.Pow(-1, num % 2 + 1);
                float y = gridOffsetY * ((num % div) / 2);

                Vector3 vec = new Vector3(x, y, 0);

                num++;

                gridList.Add(vec);
            }
        }
    }

    public Vector3 GetVector(int ID)
    {
        return transform.position + gridList[ID];
    }

    void SetDiving()
    {
        if(enemyList.Count>0)
        {
            int chosenPath = Random.Range(0, divePathList.Count);
            int chosenEnemy = Random.Range(0, enemyList.Count);

            // Double-check that the chosen enemy still exists
            if (enemyList[chosenEnemy] != null && enemyList[chosenEnemy].enemy != null)
            {
                // Instantiate a new path and initiate diving for the selected enemy
                GameObject newPath = Instantiate(divePathList[chosenPath], enemyList[chosenEnemy].start + transform.position, Quaternion.identity);
                enemyList[chosenEnemy].enemy.GetComponent<EnemyBehavior>().DiveSetup(newPath.GetComponent<Path>());
                
                // Remove the enemy from the list after initiating diving
                enemyList.RemoveAt(chosenEnemy);
                
                // Recursively set the next diving enemy after a random delay
                Invoke("SetDiving", Random.Range(3, 10));
            }
        }
        else
        {
            CancelInvoke("SetDiving");
            return;
        }
    }
}
