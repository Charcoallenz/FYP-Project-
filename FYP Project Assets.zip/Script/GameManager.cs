using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using TMPro;

public class GameManager : MonoBehaviour
{
    public static GameManager instance;

    static int level; // Current level
    static int score;
    static int lifes = 3;

    int enemyAmount;

    int scoreToBonusLife = 10000;

    static int bonusScore;
    static bool hasLost;

    // Game timer
    public float gameDuration = 180f; // Game ends in 3 minutes (180 seconds)
    private float gameTimer; // Track time during gameplay

    // UI Elements
    public TextMeshProUGUI timeText;  // Reference to the time text on UI


    void Awake()
    {
        instance = this;

        if (hasLost)
        {
            level = 1;
            score = 0;
            lifes = 3;
            bonusScore = 0;
            hasLost = false;
        }

        // Ensure level starts from 1 if it hasn't been set
        if (level <= 0)
        {
            level = 1;
        }
    }

    void Start()
    {
        UIScript.instance.UpdateScoreText(score);
        UIScript.instance.UpdateLifeText(lifes);
        UIScript.instance.ShowStageText(level);

        // Initialize game timer
        gameTimer = gameDuration;

        // Update the timer display initially
        UpdateTimeDisplay();
    }

    void Update()
    {
        // Count down the game timer
        gameTimer -= Time.deltaTime;

        // Update the timer display on the UI
        UpdateTimeDisplay();

        // Check if the timer has reached zero
        if (gameTimer <= 0)
        {
            EndGame();
        }
    }

    void UpdateTimeDisplay()
    {
        // Format the time as minutes and seconds (MM:SS)
        int minutes = Mathf.FloorToInt(gameTimer / 60f);
        int seconds = Mathf.FloorToInt(gameTimer % 60f);

        // Update the timeText to show the remaining time
        timeText.text = string.Format("{0:00}:{1:00}", minutes, seconds);
    }

    public void AddScore(int amount)
    {
        score += amount;
        //Debug.Log(score);

        UIScript.instance.UpdateScoreText(score);

        bonusScore += amount;
        if (bonusScore >= scoreToBonusLife)
        {
            lifes++;
            bonusScore %= scoreToBonusLife;
        }

        // Update the score in ScoreHolder
        ScoreHolder.score = score;

    }

    public void DecreaseLifes()
    {
        lifes--;

        UIScript.instance.UpdateLifeText(lifes);

        if (lifes < 0)
        {
            GameOver(); // Trigger Game Over
        }
    }

    public void AddEnemy()
    {
        enemyAmount++;
    }

    public void ReduceEnemy()
    {
        enemyAmount--;

        if (enemyAmount <= 0)
        {
            // Move to the next stage
            WinCondition();
        }
    }

    public void WinCondition()
    {
        level++;
        SceneManager.LoadScene(SceneManager.GetActiveScene().name);
    }

    void EndGame()
    {
        // End the game because the time has run out
        GameOver();
    }

    void GameOver()
    {
        ScoreHolder.score = score;
        // You can adjust "GameOver" to match the name of your Game Over scene
        SceneManager.LoadScene("GameOver");
    }
}