using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public static class ScoreHolder
{
    public static int score { get; set; }
}
