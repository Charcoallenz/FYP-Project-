using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using TMPro;  // Using TextMeshPro for the UI

public class EndScreen : MonoBehaviour
{
    public TextMeshProUGUI scoreText;  // Reference to the score Text UI element

    void Start()
    {
        // Display the score stored in ScoreHolder
        scoreText.text = "Score: " + ScoreHolder.score.ToString();
    }

    // Button to go to the Main Game
    public void GoToMainGame()
    {
        SceneManager.LoadScene("MainGame");  // Replace "MainGame" with the name of your main game scene
    }

    // Button to go to the Main Menu
    public void GoToMainMenu()
    {
        SceneManager.LoadScene("MainMenu");  // Replace "MainMenu" with the name of your main menu scene
    }

}
