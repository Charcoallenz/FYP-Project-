using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class PlayerBehavior : MonoBehaviour
{
    public int health = 3;  // Player's health
    
    //Movement Variables
    public float moveSpeed = 5f;          // Speed of the player movement
    public float minX = -7f;              // Left boundary of the player's movement
    public float maxX = 7f;               // Right boundary of the player's movement
    
    // Shooting Variables
    public GameObject arrowPrefab;        // The arrow prefab to shoot
    public Transform arrowSpawnPoint;     // The spawn point for the arrows
    public float arrowSpeed = 10f;      // Speed of the arrow
    public float fireRate = 0.5f;       // Delay between shots
    private float nextFireTime = 0f;    // Time when the player can fire again
    public int arrowDamage = 1;           // Damage dealt by each arrow

    public GameObject fireballPrefab; // Fireball prefab
    public Transform fireballSpawnPoint; // Position where fireball will be fired from
    public float fireballCooldown = 20f; // Cooldown time for using fireball
    private float nextFireballTime = 0f; // Time when fireball can be used again
    public int fireballDamage = 5; // Damage dealt by the fireball

    // UI Elements
    public Image fireballImage;  // This will hold the reference to the fireball UI image
    private Color originalColor;
    private Color greyedOutColor = new Color(0.5f, 0.5f, 0.5f, 1f);  // Greyed-out color

    private float moveInput;      // Horizontal input
    private Rigidbody2D rb;       // Reference to Rigidbody2D

    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
        rb.isKinematic = true;    // Set Rigidbody2D to Kinematic since we're controlling the movement manually

        // Store the original color of the fireball UI image
        originalColor = fireballImage.color;
    }

    void Update()
    {
        //Handle Player Movement
        HandleMovement();

        // Handle Player Shooting
        HandleShooting();

        // Check if player presses key for fireball and cooldown is done
        if (Input.GetKeyDown(KeyCode.X) && Time.time >= nextFireballTime)
        {
            UseFireball();
        }

        // Handle cooldown UI
        HandleFireballCooldown();

    }

    void HandleMovement()
    {
        // Get horizontal input (left/right arrow keys)
        moveInput = Input.GetAxis("Horizontal");

        // Calculate velocity for movement
        Vector2 movement = new Vector2(moveInput * moveSpeed, rb.velocity.y);

        // Apply the velocity to the Rigidbody2D for smoother, more consistent movement
        rb.velocity = movement;

        // Clamp the player's position if needed (optional, based on boundaries)
        float clampedX = Mathf.Clamp(transform.position.x, minX, maxX);
        transform.position = new Vector2(clampedX, transform.position.y);
    }

    void HandleShooting()
    {
        // Check if the "C" key is pressed and if enough time has passed to fire again
        if (Input.GetKeyDown(KeyCode.C) && Time.time > nextFireTime)
        {
            // Fire an arrow and set the next time the player can shoot
            ShootArrow();
            nextFireTime = Time.time + fireRate;

        }
    }

    void ShootArrow()
    {
        // Instantiate the arrow at the spawn point and rotate it to face upwards (90 degrees on the Z axis)
    GameObject arrow = Instantiate(arrowPrefab, arrowSpawnPoint.position, Quaternion.Euler(0, 0, 90));

        // Get the Rigidbody2D component on the arrow and apply velocity to it
        Rigidbody2D rb = arrow.GetComponent<Rigidbody2D>();
        rb.velocity = Vector2.up * arrowSpeed; // Adjust direction based on player's facing direction

        // Attach the ArrowDamage script to the arrow if it doesn't already exist
        if (!arrow.GetComponent<ArrowDamage>())
        {
            arrow.AddComponent<ArrowDamage>();
        }
    }

    // Fireball method
    void UseFireball()
    {
        // Instantiate the fireball at the fireball spawn point
        GameObject fireball = Instantiate(fireballPrefab, fireballSpawnPoint.position, Quaternion.Euler(0, 0, 90));

        // Get the Rigidbody2D component on the fireball and apply velocity to it
        Rigidbody2D rb = fireball.GetComponent<Rigidbody2D>();
        rb.velocity = Vector2.up * arrowSpeed; // Use the same speed as the arrow but can change if desired

        // Attach the ArrowDamage script to the fireball (same as arrow but with higher damage)
        if (!fireball.GetComponent<ArrowDamage>())
        {
            fireball.AddComponent<ArrowDamage>().damage = fireballDamage;
        }

        // Start the fireball cooldown timer
        nextFireballTime = Time.time + fireballCooldown;
    }

    // Handle the fireball cooldown UI
    void HandleFireballCooldown()
    {
        if (Time.time < nextFireballTime)
        {
            // Fireball is on cooldown, grey out the image
            fireballImage.color = greyedOutColor;
        }
        else
        {
            // Fireball is ready, restore the original color
            fireballImage.color = originalColor;
        }
    }

    public void TakeDamage(int amount)
    {
        health -= amount;

        // Update UI and lives
        GameManager.instance.DecreaseLifes();

        // If the player's health reaches zero, handle death
        if (health <= 0)
        {
            Die();
        }
    }

    // Method to handle player's death
    void Die()
    {
        // Destroy the player or trigger a death animation
        Debug.Log("Player has died!");
        Destroy(gameObject);
        // You can add game over logic here
    }

    void OnTriggerEnter2D(Collider2D col)
    {
        if (col.CompareTag("Enemy"))
        {
            // Take damage when colliding with an enemy
            TakeDamage(1);
        }
        else if (col.CompareTag("EnemyArrow"))
        {
            // Take damage when hit by an enemy arrow
            TakeDamage(1);
            Destroy(col.gameObject); // Destroy the arrow after it hits the player
        }
    }

    // Detect collision with the barriers
    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.CompareTag("Barrier"))
        {
            // Stop player from moving through the barrier by clamping position
            rb.velocity = Vector2.zero;
        }
    }


}
