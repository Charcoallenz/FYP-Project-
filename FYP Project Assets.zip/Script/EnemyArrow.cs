using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyArrow : MonoBehaviour
{
    public int damage = 1;  // Damage the arrow deals to the player

    void Start()
    {
        // Optionally destroy the arrow after a few seconds to prevent clutter
        Destroy(gameObject, 5f);
    }

    void OnTriggerEnter2D(Collider2D collision)
    {
        // Check if the arrow hits the player
        if (collision.CompareTag("Player"))
        {
            // Apply damage to the player
            PlayerBehavior player = collision.GetComponent<PlayerBehavior>();
            if (player != null)
            {
                player.TakeDamage(damage);
            }

            // Destroy the arrow after hitting the player
            Destroy(gameObject);
        }
        // You can add logic here to destroy the arrow if it hits other obstacles
    }
}
