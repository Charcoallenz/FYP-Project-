using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SpawnManager : MonoBehaviour
{
    [Header("Intervals")]
    public float enemySpawnInterval; // Interval Between Enemy Spawn
    public float waveSpawnInterval; // Interval Between Spawn
    int currentWave;

    int enemy1ID = 0; //ENEMY 1 ID
    int enemy2ID = 0; //ENEMY 1 ID
    int enemy3ID = 0; //ENEMY 1 ID


    [Header("Prefabs")]
    public GameObject enemy1Prefab; //ENEMY 1 OBJECT
    public GameObject enemy2Prefab; //ENEMY 2 OBJECT
    public GameObject enemy3Prefab; //ENEMY 3 OBJECT

    [Header("Formation")]
    public Formation enemy1Formation; //FORMATION FOR ENEMY 1
    public Formation enemy2Formation; //FORMATION FOR ENEMY 2
    public Formation enemy3Formation; //FORMATION FOR ENEMY 3

    [System.Serializable]
    public class Wave
    {
        public int enemy1Amount; //AMOUNT OF ENEMY 1
        public int enemy2Amount; //AMOUNT OF ENEMY 2
        public int enemy3Amount; //AMOUNT OF ENEMY 3

        public Path path;

        public GameObject[] pathPrefabs;
        
    }


    [Header("Waves")]
    public List <Wave> waveList = new List<Wave>();

    List<Path> activePathList = new List<Path>();

    [HideInInspector]public List<GameObject> spawnedEnemies = new List<GameObject>();

    bool spawnComplete;

    // Start is called before the first frame update
    void Start()
    {
        Invoke("StartSpawn", 3f);
    }

    IEnumerator SpawnWaves()
    {
        while(currentWave < waveList.Count)
        {
            if(currentWave == waveList.Count-1)
            {
                spawnComplete = true;
            }
         
            for (int i = 0; i < waveList[currentWave].pathPrefabs.Length; i++)
            {
                GameObject newPathObj = Instantiate(waveList[currentWave].pathPrefabs[i], transform.position, Quaternion.identity) as GameObject;
                Path newPath = newPathObj.GetComponent<Path>();
                activePathList.Add(newPath);
            }


            //ENEMY 1 SPAWN
            for (int i = 0; i < waveList[currentWave].enemy1Amount; i++)
            {
                GameObject newEnemy1 = Instantiate(enemy1Prefab, transform.position, Quaternion.identity) as GameObject;
                EnemyBehavior enemy1Behavior = newEnemy1.GetComponent<EnemyBehavior>();

                enemy1Behavior.SpawnSetup(activePathList[PathPingPong()], enemy1ID, enemy1Formation);
                enemy1ID++;

                spawnedEnemies.Add(newEnemy1);

                // Report to Game Manager
                GameManager.instance.AddEnemy();

                // Wait for Spawn Interval
                yield return new WaitForSeconds(enemySpawnInterval);
            }

            //ENEMY 2 SPAWN
            for (int i = 0; i < waveList[currentWave].enemy2Amount; i++)
            {
                GameObject newEnemy2 = Instantiate(enemy2Prefab, transform.position, Quaternion.identity) as GameObject;
                EnemyBehavior enemy2Behavior = newEnemy2.GetComponent<EnemyBehavior>();

                enemy2Behavior.SpawnSetup(waveList[currentWave].path, enemy2ID, enemy2Formation);
                enemy2ID++;

                spawnedEnemies.Add(newEnemy2);

                // Report to Game Manager
                GameManager.instance.AddEnemy();

                // Wait for Spawn Interval
                yield return new WaitForSeconds(enemySpawnInterval);
            }

            //ENEMY 3 SPAWN
            for (int i = 0; i < waveList[currentWave].enemy3Amount; i++)
            {
                GameObject newEnemy3 = Instantiate(enemy3Prefab, transform.position, Quaternion.identity) as GameObject;
                EnemyBehavior enemy3Behavior = newEnemy3.GetComponent<EnemyBehavior>();

                enemy3Behavior.SpawnSetup(waveList[currentWave].path, enemy3ID, enemy3Formation);
                enemy3ID++;

                spawnedEnemies.Add(newEnemy3);

                // Report to Game Manager
                GameManager.instance.AddEnemy();

                // Wait for Spawn Interval
                yield return new WaitForSeconds(enemySpawnInterval);
            }

            yield return new WaitForSeconds(waveSpawnInterval);
            currentWave++;

            foreach(Path p in activePathList)
            {
                Destroy(p.gameObject);
            }
            activePathList.Clear();
        }

        Invoke("CheckEnemyState", 1f);
    }

    // Check Interval
    void CheckEnemyState()
    {
        bool inFormation = false;
        for (int i = spawnedEnemies.Count-1; i > 0; i--)
        {
            if(spawnedEnemies[i].GetComponent<EnemyBehavior>().enemyState != EnemyBehavior.EnemyStates.IDLE)
            {
                inFormation = false;
                Invoke("CheckEnemyState", 1f);
                break;
            }
            inFormation = true;

            if(inFormation)
            {
                StartCoroutine(enemy1Formation.ActivateSpread());
                StartCoroutine(enemy2Formation.ActivateSpread());
                StartCoroutine(enemy3Formation.ActivateSpread());
                CancelInvoke("CheckEnemyState");
            }
        }
    }

    void StartSpawn()
    {
        StartCoroutine(SpawnWaves());
        CancelInvoke("StartSpawn");
    }

    int PathPingPong()
    {
        return (enemy1ID) % activePathList.Count;
    }

    void ReportToGameManager()
    {
        if(spawnedEnemies.Count == 0 && spawnComplete)
        {
            GameManager.instance.WinCondition();
        }
    }

    public void UpdateSpawnedEnemies(GameObject enemy)
    {
        spawnedEnemies.Remove(enemy);

        ReportToGameManager();
    }
}
