using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;  // Required for SceneManager

public class MainMenu : MonoBehaviour
{
    // Button to start the game and load the main game scene
    public void PlayGame()
    {
        SceneManager.LoadScene("MainGame");  // Replace "MainGame" with the name of your main game scene
    }

    // Button to quit the game
    public void QuitGame()
    {
        Debug.Log("Quitting game...");  // Log message in the editor
        Application.Quit();  // Exits the game, only works in the built game
    }
}