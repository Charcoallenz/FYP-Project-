using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ArrowDamage : MonoBehaviour
{
    public int damage = 1;  // The damage this arrow deals

    // Detect collisions with the enemy
    private void OnTriggerEnter2D(Collider2D collision)
    {
        // Check if the arrow collided with an enemy
        if (collision.CompareTag("Enemy"))
        {
            // Get the EnemyBehavior script from the collided object
            EnemyBehavior enemy = collision.GetComponent<EnemyBehavior>();

            if (enemy != null)
            {
                // Apply damage to the enemy
                enemy.TakeDamage(damage);
            }

            // Destroy the arrow after hitting the enemy
            Destroy(gameObject);
        }

    // Check if the arrow collided with the top boundary
        else if (collision.CompareTag("TopBoundary"))
        {
            // Destroy the arrow if it hits the top boundary
            Destroy(gameObject);
        }
    }
}